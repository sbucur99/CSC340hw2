package com.csc340.RestAPI;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

/**
 *
 * @author sentini
 */
@RestController
public class RestApiController {

    @GetMapping("/hello")
    public String hello(@RequestParam(value = "name", defaultValue = "World") String name) {
        return String.format("Hello, %s!", name);
    }
    
    /**
     * Get real time of a time zone
     * 
     * @return
     */
    @GetMapping("/time")
    public Object getTime() {
        String url = "https://www.timeapi.io/api/Time/current/zone?timeZone=Europe/Amsterdam";
        RestTemplate restTemplate = new RestTemplate();
        Object jSonTime = restTemplate.getForObject(url, Object.class);
        
        //Print the whole response to console.
        String time = restTemplate.getForObject(url, String.class);
        //Parse out the most important info from the response.
        JSONObject jo = new JSONObject(time);
        System.out.println(jo.toString());
        String timeYear = jo.getString("year");
        String timeMonth = jo.getString("month");
        String timeDay = jo.getString("day");
        String timeHour = jo.getString("content");
        String timeMinute = jo.getString("hour");
        String timeSeconds = jo.getString("seconds");
        String timeMilliseconds = jo.getString("milliseconds");
        
        System.out.print("this is my api assignment");
        System.out.println("got from: https://www.timeapi.io/swagger/index.html");
        
        return jSonTime;
    }

}
